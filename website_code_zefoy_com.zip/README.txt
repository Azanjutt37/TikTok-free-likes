# WEBSITE CODE EXTRACTIONS REPORT 

Website: https://zefoy.com/

EXTRACTION DATE: 11589519.318946488

## Summary:

- HTML FILES: 1

- CSS FILES: 2

- INLINE CSS BLOCKS: 1

- JAVASCRIPT FILES: 9

- INLINE JAVASCRIPT BLOCKS: 1

- API ENDPOINTS FOUND: 3

- IMAGES FOUND: 1

## Files Structure:

- index.html (Main HTML file)

- css/ (All CSS files)

- js/ (All JavaScript files)

- api_endpoints.txt (List of found API endpoints)

## Note:

This extraction includes all publicly accessible code from the website.

Some dynamic content loaded via AJAX may not be included.

